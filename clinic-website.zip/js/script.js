
 // Chaurang Homeopathic Clinic - JavaScript

const STORAGE = {
    patient: "currentPatient",
    doctor: "currentDoctor",
    appointments: "clinicAppointments",
    reviews: "chaurangPatientReviews",
    notes: "chaurangVisitNotes"
};

let selectedLoginRole = "patient";

function readList(key) {
    try {
        const data = JSON.parse(localStorage.getItem(key) || "[]");
        return Array.isArray(data) ? data : [];
    } catch {
        return [];
    }
}

function saveList(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// LOGIN MODAL
function openPatientLogin() {
    selectedLoginRole = "patient";
    const title = document.getElementById("loginTitle");
    if (!title) return;

    title.textContent = "Patient Login";
    document.getElementById("loginDescription").textContent =
        "Enter your username and password to open the patient dashboard.";
    document.getElementById("loginMessage").textContent = "";
    document.getElementById("loginModal").style.display = "flex";
}

function openDoctorLogin() {
    selectedLoginRole = "doctor";
    const title = document.getElementById("loginTitle");
    if (!title) return;

    title.textContent = "Doctor Login";
    document.getElementById("loginDescription").textContent =
        "Enter your username and password to open the doctor dashboard.";
    document.getElementById("loginMessage").textContent = "";
    document.getElementById("loginModal").style.display = "flex";
}

function closeLogin() {
    const modal = document.getElementById("loginModal");
    if (modal) modal.style.display = "none";
}

function goToAppointment() {
    const section = document.getElementById("appointment");

    if (section) {
        section.scrollIntoView({ behavior: "smooth" });
    } else {
        window.location.href = "index.html#appointment";
    }
}

function bookAppointment() {
    window.location.href = "index.html#appointment";
}

function logout() {
    localStorage.removeItem(STORAGE.patient);
    window.location.href = "index.html";
}

function logoutDoctor() {
    localStorage.removeItem(STORAGE.doctor);
    window.location.href = "index.html";
}

// INITIALIZE PAGE
document.addEventListener("DOMContentLoaded", function () {
    // Login
    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value;
            const message = document.getElementById("loginMessage");

            if (!username || !password) {
                message.textContent = "Please enter both username and password.";
                return;
            }

            // Existing login behavior is preserved.
            // This is not secure password authentication.
            if (selectedLoginRole === "patient") {
                localStorage.setItem(STORAGE.patient, username);
                localStorage.removeItem(STORAGE.doctor);
                window.location.href = "patient.html";
            } else {
                localStorage.setItem(STORAGE.doctor, username);
                localStorage.removeItem(STORAGE.patient);
                window.location.href = "doctor.html";
            }
        });
    }

    // APPOINTMENT FORM - SAVE TO PHP AND MYSQL
    const appointmentForm = document.getElementById("appointmentForm");

    if (appointmentForm) {
        appointmentForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            const patientName =
                document.getElementById("patientName").value.trim();
            const age =
                document.getElementById("patientAge").value.trim();
            const phone =
                document.getElementById("patientPhone").value.trim();
            const date =
                document.getElementById("appointmentDate").value;
            const time =
                document.getElementById("appointmentTime").value;
            const problem =
                document.getElementById("problem").value.trim();
            const message =
                document.getElementById("appointmentMessage");

            if (!patientName || !age || !phone || !date || !time || !problem) {
                message.textContent = "Please fill in all appointment details.";
                message.style.color = "red";
                return;
            }

            if (Number(age) < 1 || Number(age) > 120) {
                message.textContent = "Please enter a valid age.";
                message.style.color = "red";
                return;
            }

            if (!/^[6-9]\d{9}$/.test(phone)) {
                message.textContent =
                    "Enter a valid 10-digit Indian mobile number.";
                message.style.color = "red";
                return;
            }

            const bookedBy = localStorage.getItem(STORAGE.patient) || "";
            const submitButton =
                appointmentForm.querySelector('button[type="submit"]');

            message.textContent = "Saving appointment...";
            message.style.color = "blue";

            if (submitButton) submitButton.disabled = true;

            try {
                const response = await fetch("php/save_appointment.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        patientName: patientName,
                        age: age,
                        phone: phone,
                        date: date,
                        time: time,
                        problem: problem,
                        bookedBy: bookedBy
                    })
                });

                const result = await response.json();

                if (!response.ok || !result.success) {
                    throw new Error(
                        result.message || "Could not save appointment."
                    );
                }

                // Keep a local copy for the existing dashboards for now.
                const appointment = {
                    patientName: patientName,
                    age: age,
                    phone: phone,
                    date: date,
                    time: time,
                    problem: problem,
                    status: "Requested",
                    bookedBy: bookedBy
                };

                const appointments = readList(STORAGE.appointments);
                appointments.push(appointment);
                saveList(STORAGE.appointments, appointments);

                message.textContent =
                    "Appointment request saved successfully!";
                message.style.color = "green";
                appointmentForm.reset();

                if (bookedBy) {
                    setTimeout(function () {
                        window.location.href = "patient.html";
                    }, 800);
                }
            } catch (error) {
                message.textContent =
                    error.message ||
                    "Unable to save appointment. Make sure the PHP server is running.";
                message.style.color = "red";
            } finally {
                if (submitButton) submitButton.disabled = false;
            }
        });
    }

    // Patient dashboard
    if (document.body.dataset.page === "patient") {
        const patientName = localStorage.getItem(STORAGE.patient);

        if (!patientName) {
            window.location.href = "index.html";
            return;
        }

        document.getElementById("patientUsername").textContent = patientName;
        showAppointments();
        setupPatientReview(patientName);
        setupVisitCompanion(patientName);
    }

    // Doctor dashboard
    if (document.body.dataset.page === "doctor") {
        if (!localStorage.getItem(STORAGE.doctor)) {
            window.location.href = "index.html";
            return;
        }

        loadAppointments();
        renderDoctorReviews();
        renderDoctorNotes();
    }

    // Homepage reviews
    if (document.getElementById("reviewsList")) {
        renderHomepageReviews();
    }
});

// PATIENT APPOINTMENTS

async function showAppointments() {
    const results = document.getElementById("appointmentResults");
    if (!results) return;

    const username = localStorage.getItem(STORAGE.patient) || "";

    results.textContent = "Loading your appointments...";

    try {
        const response = await fetch("php/list_appointments.php");
        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error("Could not load appointments.");
        }

        const appointments = (data.appointments || []).filter(
            function (appointment) {
                return appointment.bookedBy === username;
            }
        );

        results.replaceChildren();

        if (appointments.length === 0) {
            results.textContent = "No appointments booked yet.";
            return;
        }

        appointments.forEach(function (appointment) {
            const card = document.createElement("div");
            card.className = "patient-appointment-item";

            const details = [
                "Patient: " + appointment.patientName,
                "Age: " + appointment.age,
                "Mobile: " + appointment.phone,
                "Date: " + appointment.date,
                "Time: " + appointment.time,
                "Reason: " + appointment.problem,
                "Status: " + appointment.status
            ];

            details.forEach(function (detail) {
                const p = document.createElement("p");
                p.textContent = detail;
                card.appendChild(p);
            });

            results.appendChild(card);
        });
    } catch (error) {
        console.error(error);
        results.textContent =
            "Could not load appointments. Please check the server.";
    }
}


// DOCTOR APPOINTMENTS

async function loadAppointments() {
    const body = document.getElementById("appointmentsBody");
    if (!body) return;

    try {
        const response = await fetch("php/list_appointments.php");
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error("Could not load appointments.");
        }

        const appointments = result.appointments || [];
        body.replaceChildren();

        document.getElementById("totalAppointments").textContent =
            appointments.length;

        document.getElementById("requestedAppointments").textContent =
            appointments.filter(a => a.status === "Requested").length;

        document.getElementById("confirmedAppointments").textContent =
            appointments.filter(a => a.status === "Confirmed").length;

        document.getElementById("emptyMessage").hidden =
            appointments.length > 0;

        document.getElementById("appointmentsTable").hidden =
            appointments.length === 0;

        appointments.forEach(function (appointment) {
            const row = document.createElement("tr");

            [
                appointment.patientName,
                appointment.age,
                appointment.phone,
                appointment.date,
                appointment.time,
                appointment.problem,
                appointment.status
            ].forEach(function (value) {
                const cell = document.createElement("td");
                cell.textContent = value ?? "-";
                row.appendChild(cell);
            });

            const actionCell = document.createElement("td");
            const button = document.createElement("button");

            button.textContent =
                appointment.status === "Confirmed"
                    ? "Confirmed"
                    : "Confirm";

            button.disabled = appointment.status === "Confirmed";

            button.addEventListener("click", async function () {
                button.disabled = true;
                button.textContent = "Updating...";

                try {
                    const updateResponse = await fetch(
                        "php/update_appointment.php",
                        {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                id: appointment.id,
                                status: "Confirmed"
                            })
                        }
                    );

                    const updateResult = await updateResponse.json();

                    if (!updateResponse.ok || !updateResult.success) {
                        throw new Error("Could not confirm appointment.");
                    }

                    await loadAppointments();
                } catch (error) {
                    alert(error.message);
                    button.disabled = false;
                    button.textContent = "Confirm";
                }
            });

            actionCell.appendChild(button);
            row.appendChild(actionCell);
            body.appendChild(row);
        });
    } catch (error) {
        console.error(error);

        const emptyMessage = document.getElementById("emptyMessage");
        if (emptyMessage) {
            emptyMessage.hidden = false;
            emptyMessage.textContent =
                "Could not load appointments. Check the PHP server.";
        }
    }
}

// PATIENT REVIEWS
function setupPatientReview(patientName) {
    const form = document.getElementById("patientReviewForm");
    if (!form) return;

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        const rating = Number(document.getElementById("patientRating").value);
        const reviewText = document.getElementById("patientReviewText").value.trim();
        const message = document.getElementById("patientReviewMessage");

        if (rating < 1 || rating > 5 || !reviewText) {
            message.textContent = "Please select a rating and enter your review.";
            return;
        }

        const reviews = readList(STORAGE.reviews);

        reviews.push({
            name: patientName,
            rating: rating,
            text: reviewText,
            date: new Date().toLocaleDateString()
        });

        saveList(STORAGE.reviews, reviews);

        message.textContent =
            "Review submitted! It will appear on the homepage and doctor dashboard in this browser.";

        form.reset();
    });
}

function renderHomepageReviews() {
    const list = document.getElementById("reviewsList");
    if (!list) return;

    const reviews = readList(STORAGE.reviews);
    const average = document.getElementById("averageRating");
    const count = document.getElementById("reviewCount");

    list.replaceChildren();

    if (reviews.length === 0) {
        average.textContent = "No ratings yet";
        count.textContent =
            "Be the first to share feedback from your Patient Dashboard.";
        list.textContent = "No reviews have been submitted yet.";
        return;
    }

    const total = reviews.reduce(function (sum, review) {
        return sum + Number(review.rating);
    }, 0);

    average.textContent = (total / reviews.length).toFixed(1) + " / 5 ★";
    count.textContent = reviews.length +
        (reviews.length === 1 ? " review" : " reviews");

    reviews.slice().reverse().forEach(function (review) {
        const card = document.createElement("article");
        card.className = "review-card";

        const name = document.createElement("h4");
        name.textContent = review.name;

        const stars = document.createElement("p");
        stars.className = "review-stars";
        stars.textContent =
            "★".repeat(Number(review.rating)) +
            "☆".repeat(5 - Number(review.rating));

        const text = document.createElement("p");
        text.textContent = review.text;

        const date = document.createElement("p");
        date.className = "review-date";
        date.textContent = (review.date || "") + " · User-submitted";

        card.append(name, stars, text, date);
        list.appendChild(card);
    });
}

function renderDoctorReviews() {
    const list = document.getElementById("doctorReviews");
    if (!list) return;

    const reviews = readList(STORAGE.reviews);
    list.replaceChildren();

    document.getElementById("doctorReviewSummary").textContent =
        reviews.length +
        (reviews.length === 1 ? " review submitted." : " reviews submitted.");

    if (reviews.length === 0) {
        list.textContent = "No reviews yet.";
        return;
    }

    reviews.slice().reverse().forEach(function (review) {
        const card = document.createElement("article");
        card.className = "review-card";

        const name = document.createElement("h4");
        name.textContent = review.name;

        const stars = document.createElement("p");
        stars.className = "review-stars";
        stars.textContent =
            "★".repeat(Number(review.rating)) +
            "☆".repeat(5 - Number(review.rating));

        const text = document.createElement("p");
        text.textContent = review.text;

        const date = document.createElement("p");
        date.className = "review-date";
        date.textContent = review.date || "";

        card.append(name, stars, text, date);
        list.appendChild(card);
    });
}

// CLINIC VISIT COMPANION
function setupVisitCompanion(patientName) {
    const saveButton = document.getElementById("saveVisitCompanion");
    const summaryButton = document.getElementById("prepareVisitSummary");

    if (!saveButton || !summaryButton) return;

    function buildNote() {
        return {
            name: patientName,
            concern: document.getElementById("visitConcern").value.trim(),
            duration: document.getElementById("concernDuration").value || "Not specified",
            checklist: Array.from(document.querySelectorAll(".visit-check:checked"))
                .map(function (checkbox) {
                    return checkbox.value;
                }),
            date: new Date().toLocaleDateString()
        };
    }

    saveButton.addEventListener("click", function () {
        const note = buildNote();
        const notes = readList(STORAGE.notes);

        notes.push(note);
        saveList(STORAGE.notes, notes);

        document.getElementById("visitSaveMessage").textContent =
            "Visit notes saved. The doctor can view them in the doctor dashboard on this browser.";
    });

    summaryButton.addEventListener("click", function () {
        const note = buildNote();
        const summary = document.getElementById("visitSummary");

        summary.replaceChildren();

        const heading = document.createElement("h3");
        heading.textContent = "Visit Preparation Summary";
        summary.appendChild(heading);

        const details = [
            "Patient: " + note.name,
            "Concern: " + (note.concern || "Not entered"),
            "Duration: " + note.duration,
            "Checklist completed: " + (note.checklist.join(", ") || "None")
        ];

        details.forEach(function (detail) {
            const p = document.createElement("p");
            p.textContent = detail;
            summary.appendChild(p);
        });

        const disclaimer = document.createElement("p");
        disclaimer.textContent =
            "This is a preparation aid, not a diagnosis or medical advice.";
        summary.appendChild(disclaimer);

        summary.hidden = false;
        window.print();
    });
}

// DOCTOR VISIT NOTES
function renderDoctorNotes() {
    const list = document.getElementById("doctorVisitNotes");
    if (!list) return;

    const notes = readList(STORAGE.notes);
    list.replaceChildren();

    if (notes.length === 0) {
        list.textContent = "No visit notes saved yet.";
        return;
    }

    notes.slice().reverse().forEach(function (note) {
        const card = document.createElement("article");
        card.className = "review-card";

        const heading = document.createElement("h4");
        heading.textContent = note.name + " — " + (note.date || "");

        const concern = document.createElement("p");
        concern.textContent = "Concern: " + (note.concern || "Not entered");

        const duration = document.createElement("p");
        duration.textContent = "Duration: " + (note.duration || "Not specified");

        const checklist = document.createElement("p");
        checklist.textContent =
            "Checklist: " + ((note.checklist || []).join(", ") || "None selected");

        card.append(heading, concern, duration, checklist);
        list.appendChild(card);
    });
}
