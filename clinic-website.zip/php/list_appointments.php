
<?php
header("Content-Type: application/json");

require_once __DIR__ . "/db.php";

try {
    $stmt = $pdo->query(
        "SELECT id, patient_name, age, phone,
                appointment_date, appointment_time,
                problem, status, booked_by
         FROM appointments
         ORDER BY id DESC"
    );

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $appointments = [];

    foreach ($rows as $row) {
        $appointments[] = [
            "id" => (int)$row["id"],
            "patientName" => $row["patient_name"],
            "age" => (int)$row["age"],
            "phone" => $row["phone"],
            "date" => $row["appointment_date"],
            "time" => $row["appointment_time"],
            "problem" => $row["problem"],
            "status" => $row["status"],
            "bookedBy" => $row["booked_by"]
        ];
    }

    echo json_encode([
        "success" => true,
        "appointments" => $appointments
    ]);
} catch (PDOException $e) {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Could not load appointments."
    ]);
}
