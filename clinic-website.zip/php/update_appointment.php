
<?php
header("Content-Type: application/json");

require_once __DIR__ . "/db.php";

$data = json_decode(file_get_contents("php://input"), true);

if (
    !$data ||
    !isset($data["id"]) ||
    !is_numeric($data["id"]) ||
    ($data["status"] ?? "") !== "Confirmed"
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Invalid appointment details."
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare(
        "UPDATE appointments SET status = ? WHERE id = ?"
    );

    $stmt->execute(["Confirmed", (int)$data["id"]]);

    if ($stmt->rowCount() === 0) {
        $check = $pdo->prepare(
            "SELECT id, status FROM appointments WHERE id = ?"
        );
        $check->execute([(int)$data["id"]]);
        $appointment = $check->fetch(PDO::FETCH_ASSOC);

        if (!$appointment || $appointment["status"] !== "Confirmed") {
            http_response_code(404);
            echo json_encode([
                "success" => false,
                "message" => "Appointment not found."
            ]);
            exit;
        }
    }

    echo json_encode([
        "success" => true,
        "message" => "Appointment confirmed successfully."
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Could not update appointment."
    ]);
}
