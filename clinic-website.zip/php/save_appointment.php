
<?php
header("Content-Type: application/json");

require_once __DIR__ . "/db.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    echo json_encode([
        "success" => false,
        "message" => "No appointment data received."
    ]);
    exit;
}

$name = trim($data["patientName"] ?? "");
$age = filter_var($data["age"] ?? null, FILTER_VALIDATE_INT);
$phone = trim($data["phone"] ?? "");
$date = trim($data["date"] ?? "");
$time = trim($data["time"] ?? "");
$problem = trim($data["problem"] ?? "");
$bookedBy = trim($data["bookedBy"] ?? "");

if (
    $name === "" ||
    $age === false || $age === null ||
    $age < 1 || $age > 120 ||
    !preg_match('/^[6-9][0-9]{9}$/', $phone) ||
    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ||
    $time === "" ||
    $problem === ""
) {
    echo json_encode([
        "success" => false,
        "message" => "Please enter valid appointment details."
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare(
        "INSERT INTO appointments
        (patient_name, age, phone, appointment_date,
         appointment_time, problem, status, booked_by)
        VALUES (?, ?, ?, ?, ?, ?, 'Requested', ?)"
    );

    $stmt->execute([
        $name,
        $age,
        $phone,
        $date,
        $time,
        $problem,
        $bookedBy
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Appointment saved successfully!"
    ]);

} catch (PDOException $e) {
    http_response_code(500);

    error_log("Appointment save error: " . $e->getMessage());

    echo json_encode([
        "success" => false,
        "message" => "Database save failed. Check the PHP server terminal for the exact error."
    ]);
}
