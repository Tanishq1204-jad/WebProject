<?php
session_start();

$message = "";
$messageType = "";

$patientName = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $patientName = trim($_POST["patientName"] ?? "");
    $email = trim($_POST["email"] ?? "");

    // Validate required fields
    if ($patientName === "" || $email === "") {
        $message = "Please fill in all fields.";
        $messageType = "error";

    // Validate email format
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
        $messageType = "error";

    } else {
        // Store patient details in the session
        $_SESSION["patient_name"] = $patientName;
        $_SESSION["patient_email"] = $email;

        $message = "Thank you, " .
            htmlspecialchars($patientName, ENT_QUOTES, "UTF-8") .
            ". Your enquiry has been received.";

        $messageType = "success";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Patient Enquiry | Chaurang Homeopathic Clinic</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #f1f7ef;
            color: #26352b;
        }

        .container {
            max-width: 520px;
            margin: 30px auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 18px #00000012;
        }

        h1 {
            color: #247443;
            text-align: center;
        }

        h2 {
            color: #e58a2b;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 18px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-top: 7px;
            border: 1px solid #cbd9ca;
            border-radius: 6px;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 22px;
            border: none;
            border-radius: 6px;
            background: #247443;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #185b34;
        }

        .success {
            padding: 12px;
            background: #e2f5e6;
            color: #185b34;
            border-radius: 6px;
        }

        .error {
            padding: 12px;
            background: #ffebeb;
            color: #a12020;
            border-radius: 6px;
        }

        .back {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #247443;
        }
    </style>
</head>

<body>

    <div class="container">

        <h1>🌿 Chaurang Homeopathic Clinic</h1>
        <h2>Patient Enquiry Form</h2>

        <p>
            Please enter your details to submit a patient enquiry.
        </p>

        <form method="POST" action="">

            <label for="patientName">Patient Name</label>
            <input
                type="text"
                id="patientName"
                name="patientName"
                value="<?= htmlspecialchars($patientName, ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="email">Email Address</label>
            <input
                type="email"
                id="email"
                name="email"
                value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <button type="submit">Submit Enquiry</button>

        </form>

        <?php if ($message !== ""): ?>
            <p class="<?= $messageType ?>">
                <?= $message ?>
            </p>
        <?php endif; ?>

        <a class="back" href="../index.html">
            Back to Clinic Website
        </a>

    </div>

</body>
</html>
